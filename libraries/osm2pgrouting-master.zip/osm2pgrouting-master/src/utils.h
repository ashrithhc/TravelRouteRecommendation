#include <string>

namespace my_utils{

bool is_number(const std::string& s);

}
